'use client';

import { AlertTriangle, Building2, Check, ChevronRight, ClipboardList, Eye, EyeOff, KeyRound, LayoutDashboard, LockKeyhole, MapPin, Menu, Moon, Plus, RefreshCw, ShieldCheck, Sun, UserCog, UsersRound, X } from 'lucide-react';
import { type SyntheticEvent, useEffect, useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { API_BASE_URL, getSites, type Site } from '@/lib/ptms-api';

const requestedSite: Site = {
  id: 0, organization_id: 0, name: 'Guanzon Corporate Center',
  address: 'Makati City, Metro Manila', status: 'active', latitude: null,
  longitude: null, created_at: '', updated_at: '',
};

function Brand() {
  return <div className="flex items-center gap-3"><div className="grid size-11 place-items-center rounded-xl bg-[#f36f0a] text-white shadow-[0_5px_16px_rgb(243_111_10/28%)]"><ShieldCheck className="size-7" /></div><div><p className="text-xl font-black leading-none tracking-[-.04em]">PTMS</p><p className="mt-1 text-[10px] font-bold uppercase tracking-[.18em] text-[#f36f0a]">Admin Web Portal</p></div></div>;
}

function ThemeButton({ dark, setDark }: { dark: boolean; setDark: (value: boolean) => void }) {
  return <Button aria-label={`Use ${dark ? 'light' : 'dark'} theme`} onClick={() => setDark(!dark)} size="icon" variant="outline">{dark ? <Sun /> : <Moon />}</Button>;
}

function Login({ dark, setDark, onPreview }: { dark: boolean; setDark: (v: boolean) => void; onPreview: () => void }) {
  const [showPassword, setShowPassword] = useState(false);
  const [notice, setNotice] = useState(false);
  function submit(event: SyntheticEvent<HTMLFormElement>) { event.preventDefault(); setNotice(true); }

  return <main className="grid min-h-screen bg-background lg:grid-cols-[1.05fr_.95fr]">
    <section className="relative hidden overflow-hidden bg-[#101010] p-14 text-white lg:flex lg:flex-col">
      <div className="absolute inset-0 opacity-30 [background:radial-gradient(circle_at_20%_20%,#f36f0a_0,transparent_30%),radial-gradient(circle_at_90%_80%,#6d2b00_0,transparent_35%)]" />
      <div className="relative z-10"><Brand /></div>
      <div className="relative z-10 my-auto max-w-xl"><Badge className="mb-5 border-orange-400/30 bg-orange-500/10 text-orange-300" variant="outline">Owner / Engineer workspace</Badge><h1 className="text-5xl font-black leading-[1.05] tracking-[-.055em]">One clear command center for every patrol site.</h1><p className="mt-5 max-w-lg text-lg leading-8 text-white/62">Create sites, appoint accountable leaders, and see checkpoint evidence without crossing organization boundaries.</p>
        <div className="mt-10 grid grid-cols-3 gap-3">{[['1', 'Active site'], ['3', 'Accountable roles'], ['100%', 'Backend authority']].map(([value, label]) => <div key={label} className="rounded-2xl border border-white/10 bg-white/5 p-4 backdrop-blur"><p className="text-2xl font-black text-[#ff8121]">{value}</p><p className="mt-1 text-xs text-white/50">{label}</p></div>)}</div>
      </div>
      <p className="relative z-10 text-xs text-white/35">Track Every Patrol. Ensure Every Checkpoint.</p>
    </section>
    <section className="flex min-h-screen flex-col p-5 sm:p-9 lg:p-14"><div className="flex items-center justify-between lg:justify-end"><div className="lg:hidden"><Brand /></div><ThemeButton dark={dark} setDark={setDark} /></div>
      <div className="m-auto w-full max-w-[430px] py-10"><div className="mb-8"><div className="mb-5 grid size-12 place-items-center rounded-xl bg-orange-100 text-[#e75f00] dark:bg-orange-500/15 dark:text-orange-400"><KeyRound /></div><h2 className="text-3xl font-black tracking-[-.04em]">Welcome back</h2><p className="mt-2 text-sm leading-6 text-muted-foreground">Sign in with your Owner or Engineer account to manage PTMS sites.</p></div>
        <form className="space-y-5" onSubmit={submit}><label className="block"><span className="mb-2 block text-sm font-bold">Email address</span><input className="h-12 w-full rounded-xl border bg-card px-4 text-sm outline-none transition focus:border-[#f36f0a] focus:ring-3 focus:ring-orange-500/10" placeholder="owner@company.com" type="email" required /></label><label className="block"><span className="mb-2 block text-sm font-bold">Password</span><span className="relative block"><input className="h-12 w-full rounded-xl border bg-card px-4 pr-12 text-sm outline-none transition focus:border-[#f36f0a] focus:ring-3 focus:ring-orange-500/10" placeholder="Enter your password" type={showPassword ? 'text' : 'password'} required /><button aria-label={showPassword ? 'Hide password' : 'Show password'} className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground" onClick={() => setShowPassword(!showPassword)} type="button">{showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}</button></span></label><Button className="h-12 w-full bg-[#f36f0a] font-bold text-white hover:bg-[#d95e00]" type="submit"><LockKeyhole />Sign in securely</Button></form>
        {notice && <div className="mt-4 flex gap-3 rounded-xl border border-amber-300 bg-amber-50 p-4 text-sm text-amber-900 dark:border-amber-500/25 dark:bg-amber-500/10 dark:text-amber-200"><AlertTriangle className="mt-0.5 size-4 shrink-0" /><p>Live sign-in is paused because the current API updates <code>last_login_at</code>. Approval or a read-only auth path is required first.</p></div>}
        <div className="my-6 flex items-center gap-3 text-xs text-muted-foreground"><span className="h-px flex-1 bg-border" />Safe preview<span className="h-px flex-1 bg-border" /></div><Button className="h-11 w-full" onClick={onPreview} variant="outline">Enter read-only Owner workspace<ChevronRight /></Button><p className="mt-4 text-center text-xs leading-5 text-muted-foreground">No live write action is performed. The workspace only attempts a public site list lookup.</p>
      </div>
    </section>
  </main>;
}

function AdminShell({ dark, setDark, onExit }: { dark: boolean; setDark: (v: boolean) => void; onExit: () => void }) {
  const [mobileNav, setMobileNav] = useState(false);
  const [sites, setSites] = useState<Site[]>([]);
  const [state, setState] = useState<'loading' | 'live' | 'offline'>('loading');

  async function refresh() {
    setState('loading');
    try { const rows = await getSites(); setSites(rows); setState('live'); }
    catch { setSites([]); setState('offline'); }
  }
  useEffect(() => { const controller = new AbortController(); getSites(controller.signal).then(rows => { setSites(rows); setState('live'); }).catch(() => { if (!controller.signal.aborted) setState('offline'); }); return () => controller.abort(); }, []);
  const guanzon = sites.find(site => site.name.toLowerCase().includes('guanzon')) ?? requestedSite;

  const nav = [{ label: 'Overview', icon: LayoutDashboard }, { label: 'Sites', icon: Building2, active: true }, { label: 'User accounts', icon: UsersRound }, { label: 'Assignments', icon: UserCog }, { label: 'Audit trail', icon: ClipboardList }];
  return <main className="min-h-screen bg-background text-foreground">
    {mobileNav && <button aria-label="Close navigation" className="fixed inset-0 z-30 bg-black/55 lg:hidden" onClick={() => setMobileNav(false)} />}
    <aside className={`fixed inset-y-0 left-0 z-40 flex w-[250px] flex-col border-r bg-[#111] text-white transition-transform lg:translate-x-0 ${mobileNav ? 'translate-x-0' : '-translate-x-full'}`}><div className="flex h-[76px] items-center justify-between border-b border-white/10 px-5"><Brand /><Button aria-label="Close navigation" className="text-white lg:hidden" onClick={() => setMobileNav(false)} size="icon" variant="ghost"><X /></Button></div><p className="px-7 pb-3 pt-6 text-[10px] font-bold uppercase tracking-[.18em] text-white/35">Management</p><nav className="space-y-1 px-3">{nav.map(item => <button key={item.label} className={`flex h-11 w-full items-center gap-3 rounded-xl px-3 text-sm font-semibold ${item.active ? 'bg-[#f36f0a] text-white shadow-lg shadow-orange-950/30' : 'text-white/60 hover:bg-white/7 hover:text-white'}`}><item.icon className="size-[18px]" />{item.label}</button>)}</nav><div className="mt-auto p-4"><div className="rounded-xl border border-white/10 bg-white/5 p-3"><p className="text-xs font-bold">Read-only safety mode</p><p className="mt-1 text-[11px] leading-4 text-white/45">Writes stay disabled until backend gaps are closed and approved.</p></div><button className="mt-3 w-full rounded-lg px-3 py-2 text-left text-xs text-white/45 hover:bg-white/5" onClick={onExit}>Return to sign in</button></div></aside>
    <section className="min-h-screen lg:pl-[250px]"><header className="sticky top-0 z-20 flex h-[76px] items-center border-b bg-background/90 px-4 backdrop-blur-xl sm:px-8"><Button aria-label="Open navigation" className="lg:hidden" onClick={() => setMobileNav(true)} size="icon" variant="ghost"><Menu /></Button><div className="ml-3 lg:ml-0"><p className="text-xs font-bold uppercase tracking-[.14em] text-muted-foreground">Owner / Engineer</p><p className="text-sm font-black">Site Management</p></div><div className="ml-auto flex items-center gap-2"><Badge className={state === 'live' ? 'border-emerald-300 bg-emerald-50 text-emerald-800 dark:bg-emerald-500/10 dark:text-emerald-300' : state === 'offline' ? 'border-amber-300 bg-amber-50 text-amber-800 dark:bg-amber-500/10 dark:text-amber-300' : ''} variant="outline">{state === 'live' ? 'Live read-only' : state === 'offline' ? 'Reference data' : 'Checking API…'}</Badge><ThemeButton dark={dark} setDark={setDark} /><div className="hidden size-9 place-items-center rounded-full bg-[#f36f0a] text-xs font-black text-white sm:grid">OE</div></div></header>
      <div className="mx-auto max-w-[1280px] p-4 sm:p-8"><div className="flex flex-col gap-4 border-b pb-7 sm:flex-row sm:items-end sm:justify-between"><div><p className="text-sm font-bold text-[#e86405]">Initial site-management foundation</p><h1 className="mt-1 text-3xl font-black tracking-[-.045em] sm:text-4xl">Sites & accountability</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">Site details and role accountability are visible here. Backend rules remain authoritative; unavailable controls are intentionally locked.</p></div><div className="flex gap-2"><Button onClick={refresh} variant="outline"><RefreshCw className={state === 'loading' ? 'animate-spin' : ''} />Refresh read-only data</Button><Button disabled title="Blocked pending backend authorization and approval"><Plus />Create site</Button></div></div>
        <div className="mt-6 flex gap-3 rounded-xl border border-orange-200 bg-orange-50 p-4 text-sm text-orange-950 dark:border-orange-500/20 dark:bg-orange-500/8 dark:text-orange-100"><LockKeyhole className="mt-0.5 size-5 shrink-0 text-[#e86405]" /><div><p className="font-bold">Safe connection posture</p><p className="mt-1 text-xs leading-5 opacity-75">Only <code>GET /sites</code> is called against {API_BASE_URL}. Login, creation, assignments, handover, edits, and deactivation are blocked.</p></div></div>
        <section className="mt-6 grid gap-4 sm:grid-cols-3"><div className="rounded-2xl border bg-card p-5"><p className="text-xs font-bold uppercase tracking-[.12em] text-muted-foreground">Active sites</p><p className="mt-2 text-3xl font-black">{state === 'live' ? sites.filter(s => s.status === 'active').length : '1'}</p><p className="mt-2 text-xs text-muted-foreground">Organization-scoped target</p></div><div className="rounded-2xl border bg-card p-5"><p className="text-xs font-bold uppercase tracking-[.12em] text-muted-foreground">Leadership slots</p><p className="mt-2 text-3xl font-black">3</p><p className="mt-2 text-xs text-muted-foreground">Site Admin · Supervisor · OIC</p></div><div className="rounded-2xl border bg-card p-5"><p className="text-xs font-bold uppercase tracking-[.12em] text-muted-foreground">Writes enabled</p><p className="mt-2 text-3xl font-black text-[#e86405]">0</p><p className="mt-2 text-xs text-muted-foreground">Awaiting backend readiness</p></div></section>

        <section className="mt-6 overflow-hidden rounded-2xl border bg-card shadow-[0_12px_35px_rgb(15_23_42/5%)]"><div className="flex flex-col gap-3 border-b p-5 sm:flex-row sm:items-center sm:justify-between"><div className="flex items-center gap-4"><div className="grid size-12 place-items-center rounded-xl bg-orange-100 text-[#e86405] dark:bg-orange-500/15 dark:text-orange-400"><Building2 /></div><div><div className="flex flex-wrap items-center gap-2"><h2 className="text-lg font-black">{guanzon.name}</h2><Badge className="border-emerald-300 bg-emerald-50 text-emerald-800 dark:bg-emerald-500/10 dark:text-emerald-300" variant="outline">Active</Badge>{guanzon.id === 0 && <Badge variant="outline">Planned first site</Badge>}</div><p className="mt-1 flex items-center gap-1.5 text-xs text-muted-foreground"><MapPin className="size-3.5" />{guanzon.address ?? 'Address not configured'}</p></div></div><Button disabled variant="outline">Edit site</Button></div>
          <div className="grid divide-y lg:grid-cols-3 lg:divide-x lg:divide-y-0">{[
            { title: 'Site Admin', owner: 'Not assigned', rule: 'Assigned by Owner / Engineer', icon: UserCog },
            { title: 'Supervisor', owner: 'Not assigned', rule: 'Assigned by Owner / Engineer', icon: UsersRound },
            { title: 'OIC', owner: 'Not assigned', rule: 'Controlled by Site Admin', icon: ShieldCheck },
          ].map(role => <article key={role.title} className="p-5"><div className="flex items-center justify-between"><div className="grid size-9 place-items-center rounded-lg bg-muted text-muted-foreground"><role.icon className="size-4" /></div><Badge className="border-amber-300 bg-amber-50 text-amber-800 dark:bg-amber-500/10 dark:text-amber-300" variant="outline">Vacant</Badge></div><h3 className="mt-5 text-sm font-black">{role.title}</h3><p className="mt-1 text-lg font-bold text-muted-foreground">{role.owner}</p><p className="mt-3 text-xs text-muted-foreground">{role.rule}</p><Button className="mt-4 w-full" disabled variant="outline">Assign {role.title}</Button></article>)}</div>
          <div className="grid gap-3 border-t bg-muted/25 p-5 md:grid-cols-3"><div className="flex items-start gap-3"><Check className="mt-0.5 size-4 text-emerald-600" /><p className="text-xs leading-5"><strong>Any site guard</strong> may perform any checkpoint.</p></div><div className="flex items-start gap-3"><Check className="mt-0.5 size-4 text-emerald-600" /><p className="text-xs leading-5"><strong>NFC, selfie, and timestamp</strong> form completion evidence.</p></div><div className="flex items-start gap-3"><Check className="mt-0.5 size-4 text-emerald-600" /><p className="text-xs leading-5"><strong>OIC at the time</strong> is accountable for missed checkpoints.</p></div></div>
        </section>
        <section className="mt-6 rounded-2xl border border-red-200 bg-red-50 p-5 dark:border-red-500/20 dark:bg-red-500/8"><div className="flex items-start gap-3"><AlertTriangle className="mt-0.5 size-5 shrink-0 text-red-600" /><div><h2 className="font-black text-red-950 dark:text-red-200">Backend/schema gaps found</h2><p className="mt-1 text-sm leading-6 text-red-900/75 dark:text-red-100/65">Owner/Engineer roles, named site assignments, single-active constraints, OIC handover history, missed-checkpoint accountability snapshots, assignment permission rules, and protected tenant-derived site routes are not yet available. Full findings are documented in <code>BACKEND_GAPS.md</code>.</p></div></div></section>
      </div>
    </section>
  </main>;
}

export default function Home() {
  const [dark, setDark] = useState(() => typeof window !== 'undefined' && (localStorage.getItem('ptms-theme') === 'dark' || (!localStorage.getItem('ptms-theme') && matchMedia('(prefers-color-scheme: dark)').matches)));
  const [preview, setPreview] = useState(false);
  useEffect(() => { document.documentElement.classList.toggle('dark', dark); localStorage.setItem('ptms-theme', dark ? 'dark' : 'light'); }, [dark]);
  return preview ? <AdminShell dark={dark} setDark={setDark} onExit={() => setPreview(false)} /> : <Login dark={dark} setDark={setDark} onPreview={() => setPreview(true)} />;
}
