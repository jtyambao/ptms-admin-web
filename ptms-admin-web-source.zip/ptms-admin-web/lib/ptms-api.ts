export const API_BASE_URL =
  process.env.NEXT_PUBLIC_PTMS_API_BASE_URL ?? 'https://ptms-api.onrender.com/api/v1';

export type Site = {
  id: number;
  organization_id: number;
  name: string;
  address: string | null;
  status: 'active' | 'inactive';
  latitude: number | null;
  longitude: number | null;
  created_at: string;
  updated_at: string;
};

type Envelope<T> = { success: boolean; message: string; data: T };

export async function getSites(signal?: AbortSignal): Promise<Site[]> {
  const response = await fetch(`${API_BASE_URL}/sites`, {
    method: 'GET',
    headers: { Accept: 'application/json' },
    signal,
  });
  if (!response.ok) throw new Error(`Site lookup failed (${response.status}).`);
  return (await response.json() as Envelope<Site[]>).data;
}
