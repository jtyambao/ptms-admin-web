# Backend gaps blocking Admin Web writes

The Admin Web remains read-only until these items are implemented and approved.

1. **Owner/Engineer identity is missing.** The API user-role enum only supports `super_admin`, `org_admin`, `site_manager`, `supervisor`, `auditor`, and `client_viewer`. The roadmap also says the Owner/Engineer management account tier is not built.
2. **Login is not read-only.** `POST /auth/login` updates `users.last_login_at`, so it is intentionally not called while live-data writes are prohibited.
3. **Site routes are public and tenant input is client-controlled.** `GET/POST /sites` have no JWT/RBAC guard, and create accepts `organizationId` from the request body instead of deriving it from the authenticated user.
4. **Site assignment records do not exist.** `users` has no `site_id`, and there is no assignment/history table for Site Admin, Supervisor, or OIC.
5. **Single-active-role rules are not enforced.** There are no database constraints or authoritative services guaranteeing one active Site Admin, one active Supervisor, and one active OIC per site.
6. **OIC is modeled inconsistently.** The original `site_manager` web role is described as OIC, while the newer guard flow uses one shared site MPIN in `site_credentials` and does not record a named, time-bounded OIC assignment.
7. **OIC accountability cannot be reconstructed.** Missed checkpoint records have a site and timestamps but no immutable OIC-at-the-time assignment reference.
8. **Assignment permissions are absent.** The API cannot enforce Owner/Engineer-only Site Admin/Supervisor assignment, Site Admin-controlled OIC handover, or the prohibition on self-assignment.
9. **Several resource routes are still unauthenticated.** Sites, personnel, and checkpoints expose reads and writes without the web JWT guard; tenant isolation cannot safely rely on the browser.
10. **Site management is create/read only.** There are no authenticated update/deactivate endpoints for site profile, status, or coordinates.

Recommended backend slice: add explicit `owner` and `engineer` roles (or formally map them to a single approved role), introduce time-bounded site-role assignments with partial unique constraints for one active assignee per role/site, snapshot the active OIC onto missed-checkpoint evidence, enforce permissions server-side, then secure all admin routes with JWT + organization context.
